package com.data;

import java.util.List;

import com.model.Banquet;

public interface BanquetDAO {
	
public List<Banquet> getBanquets() throws Exception;
	
//	void addItem(HttpServletRequest request) throws Exception;
	
	void addBanquet(Banquet banquet) throws Exception;
	
	public void deleteBanquet(int id) throws Exception;
	
	public List<Banquet> searchBanquets(String gestname) throws Exception;
	
	public Banquet getBanquet(int id) throws Exception;
	
	public void updateBanquet(Banquet banquet) throws Exception;

}
