package com.data;

import java.util.List;

import com.model.Inventory;

public interface InventoryDAO {
public List<Inventory> getInventorys() throws Exception;
	
//	void addItem(HttpServletRequest request) throws Exception;
	
	void addInventory(Inventory inventory) throws Exception;
	
	public void deleteInventory(int id) throws Exception;
	
	public List<Inventory> searchInventorys(String fullName) throws Exception;
	
	public Inventory getInventory(int id) throws Exception;
	
	public void updateInventory(Inventory inventory) throws Exception;

}
