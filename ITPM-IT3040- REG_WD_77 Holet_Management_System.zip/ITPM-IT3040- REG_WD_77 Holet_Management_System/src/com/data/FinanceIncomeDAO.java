package com.data;

public interface FinanceIncomeDAO {

}
