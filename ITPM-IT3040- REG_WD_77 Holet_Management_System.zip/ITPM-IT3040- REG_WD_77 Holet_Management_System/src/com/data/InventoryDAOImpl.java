package com.data;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.model.Inventory;




public class InventoryDAOImpl implements InventoryDAO{

	@Override
	public List<Inventory> getInventorys() throws Exception {
List<Inventory> inventoryList = new ArrayList<Inventory>();
		
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			con = ConnectionFactory.getCon();
			ps = con.prepareStatement("select * from inventory order by id");
			rs = ps.executeQuery();
			
			while(rs.next()) {
				int id = rs.getInt("id");
				String inventoryName = rs.getString("inventoryName");
				String supplierName = rs.getString("supplierName");
				String supplierId = rs.getString("supplierId");
				Date date = rs.getDate("date");
				int qty = rs.getInt("qty");
				
			
				
				Inventory inventory = new Inventory(id, inventoryName, supplierName,supplierId,date,qty);
				
				inventoryList.add(inventory);
				
			}
		}
		finally {
			close(rs, ps, con);
		}
		
		return inventoryList;
	}

	private void close(ResultSet rs, PreparedStatement ps, Connection con) {
		
		try {
			
			if(rs != null) {
				rs.close();
			}
			if(ps != null) {
				ps.close();
			}
			if(con != null) {
				con.close();
			}
			
		}
		catch(Exception e) {
			e.getStackTrace();
		}
	}

	@Override
	public void addInventory(Inventory inventory) throws Exception {
		Connection con = null;
		PreparedStatement ps = null;
		
		

		try {
			con = ConnectionFactory.getCon();
			ps = con.prepareStatement("insert into inventory(inventoryName, supplierName,supplierId, date, qty) values( ?, ?, ?, ?, ?)");
			
			ps.setString(1, inventory.getInventoryName());
			ps.setString(2, inventory.getSupplierName());
			ps.setString(3, inventory.getSupplierId());
			ps.setTimestamp(4, new java.sql.Timestamp(inventory.getDate().getTime()));
			ps.setInt(5, inventory.getQty());
			
			
			
			ps.executeUpdate();
		}
		finally {
			close(null, ps, con);
		}
		
	}

	@Override
	public void deleteInventory(int id) throws Exception {
		Connection con=null;
		PreparedStatement ps=null;
		try {
			con=ConnectionFactory.getCon();
			ps=con.prepareStatement("delete from inventory where id=?");
			ps.setInt(1,id);
			ps.executeUpdate();
		}
		finally {
			close(null,ps,con);
		}
		
	}

	@Override
	public List<Inventory> searchInventorys(String inventoryname) throws Exception {
		List<Inventory> searchList=new ArrayList<>();
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		try {
			con=ConnectionFactory.getCon();
			ps=con.prepareStatement("select * from inventory where inventoryName=?");
			ps.setString(1, inventoryname);
			rs=ps.executeQuery();
			while(rs.next()) {
				int id=rs.getInt(1);
				String inventoryName=rs.getString(2);	
				String supplierNumber=rs.getString(3);	
		        String supplierId=rs.getString(4);
		        Date date=rs.getDate(5);
		        int qty=rs.getInt(6);
		      
		        
		        Inventory inventory=new Inventory(id, inventoryName, supplierNumber, supplierId, date, qty);
		        
		        searchList.add(inventory);
			}
		}
		finally {
			close(rs,ps,con);
		}
		return searchList;
	}

	@Override
	public Inventory getInventory(int id) throws Exception {
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		Inventory inventory = null;
		try {
			con=ConnectionFactory.getCon();
			ps=con.prepareStatement("select * from inventory where id=?");
			ps.setInt(1, id);
			rs=ps.executeQuery();
			if(rs.next()) {
				String inventoryName=rs.getString(2);
				String supplierNumber=rs.getString(3);
				String supplierId=rs.getString(4);
				Date date=rs.getDate(5);	
		        
		        int qty=rs.getInt(6);
		       
		        
		        inventory=new Inventory(id, inventoryName, supplierNumber, supplierId, date,qty);
		        
			}
			else {
				throw new Exception("Item Not Found");
			}
		}
		finally {
			close(rs,ps,con);
		}
		return inventory;
	}

	@Override
	public void updateInventory(Inventory inventory) throws Exception {
		// TODO Auto-generated method stub
		Connection con=null;
		PreparedStatement ps=null;
		try
		{
			con=ConnectionFactory.getCon();
			ps=con.prepareStatement("update inventory set inventoryName=?,supplierName=?,supplierId=?,date=?,qty=? where id=?");
			ps.setString(1, inventory.getInventoryName());		
			ps.setString(2, inventory.getSupplierName());
			ps.setString(3,inventory.getSupplierId());
			ps.setTimestamp(4, new java.sql.Timestamp(inventory.getDate().getTime()));
			ps.setInt(5,inventory.getQty());
			ps.setInt(6,inventory.getId());
			ps.executeUpdate();
		}
		finally {
			close(null,ps,con);
		}
		
		
	
		
	}

}
