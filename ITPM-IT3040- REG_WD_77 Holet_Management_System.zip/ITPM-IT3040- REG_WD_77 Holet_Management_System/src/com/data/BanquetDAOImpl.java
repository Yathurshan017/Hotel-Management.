package com.data;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.model.Banquet;


public class BanquetDAOImpl implements BanquetDAO{

	@Override
	public List<Banquet> getBanquets() throws Exception {
		List<Banquet> banquetList = new ArrayList<Banquet>();
		
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			con = ConnectionFactory.getCon();
			ps = con.prepareStatement("select * from banquet order by id");
			rs = ps.executeQuery();
			
			while(rs.next()) {
				int id = rs.getInt("id");
				String gestName = rs.getString("gestName");			
				String mobile = rs.getString("mobile");
				String eventType = rs.getString("eventType");
				String service = rs.getString("service");						
				String decoration = rs.getString("decoration");
				Date eDate = rs.getDate("eDate");
				
				Banquet banquet = new Banquet(id, gestName, mobile, eventType,service, decoration,eDate);
				
				banquetList.add(banquet);
				
			}
		}
		finally {
			close(rs, ps, con);
		}
		
		return banquetList;
	}

	private void close(ResultSet rs, PreparedStatement ps, Connection con) {
		
		try {
			
			if(rs != null) {
				rs.close();
			}
			if(ps != null) {
				ps.close();
			}
			if(con != null) {
				con.close();
			}
			
		}
		catch(Exception e) {
			e.getStackTrace();
		}
	}

	@Override
	public void addBanquet(Banquet banquet) throws Exception {
		Connection con = null;
		PreparedStatement ps = null;
		
		

		try {
			con = ConnectionFactory.getCon();
			ps = con.prepareStatement("insert into banquet(gestName, mobile,eventType, service, decoration, eDate) values( ?, ?, ?, ?, ?, ?)");
			
			ps.setString(1, banquet.getGestName());
			ps.setString(2, banquet.getMobile());
			ps.setString(3, banquet.getEventType());
			ps.setString(4, banquet.getService());		
			ps.setString(5, banquet.getDecoration());
			ps.setTimestamp(6, new java.sql.Timestamp(banquet.geteDate().getTime()));
			
			
			ps.executeUpdate();
		}
		finally {
			close(null, ps, con);
		}
		
	}

	@Override
	public void deleteBanquet(int id) throws Exception {
		Connection con=null;
		PreparedStatement ps=null;
		try {
			con=ConnectionFactory.getCon();
			ps=con.prepareStatement("delete from banquet where id=?");
			ps.setInt(1,id);
			ps.executeUpdate();
		}
		finally {
			close(null,ps,con);
		}
		
	}

	@Override
	public List<Banquet> searchBanquets(String gestname) throws Exception {
		List<Banquet> searchList=new ArrayList<>();
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		try {
			con=ConnectionFactory.getCon();
			ps=con.prepareStatement("select * from banquet where fullName=?");
			ps.setString(1, gestname);
			rs=ps.executeQuery();
			while(rs.next()) {
				int id=rs.getInt(1);
				String gestName=rs.getString(2);
				
				String mobile=rs.getString(3);
				String eventType = rs.getString(4);
		        String service=rs.getString(5);
		        String decoration=rs.getString(6);
		        Date eDate=rs.getDate(7);
		        
		        Banquet banquet=new Banquet(id, gestName, mobile, eventType, service, decoration, eDate);
		        
		        searchList.add(banquet);
			}
		}
		finally {
			close(rs,ps,con);
		}
		return searchList;
	}

	@Override
	public Banquet getBanquet(int id) throws Exception {
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		Banquet banquet = null;
		try {
			con=ConnectionFactory.getCon();
			ps=con.prepareStatement("select * from banquet where id=?");
			ps.setInt(1, id);
			rs=ps.executeQuery();
			if(rs.next()) {
				String gestName=rs.getString(2);
				String mobile=rs.getString(3);
				String eventType = rs.getString(4);
		        String service=rs.getString(5);
		        String decoration=rs.getString(6);
		        Date eDate=rs.getDate(7);
		       
		        
		        banquet=new Banquet(id, gestName, mobile, eventType, service, decoration,eDate);
		        
			}
			else {
				throw new Exception("Item Not Found");
			}
		}
		finally {
			close(rs,ps,con);
		}
		return banquet;
	}

	@Override
	public void updateBanquet(Banquet banquet) throws Exception {
		Connection con=null;
		PreparedStatement ps=null;
		try
		{
			con=ConnectionFactory.getCon();
			ps=con.prepareStatement("update banquet set gestName=?,mobile=?,eventType=?,service=?,decoration=?,eDate=? where id=?");
			ps.setString(1, banquet.getGestName());
			ps.setString(2, banquet.getMobile());
			ps.setString(3, banquet.getEventType());
			ps.setString(4,banquet.getService());
			ps.setString(5,banquet.getDecoration());
			ps.setTimestamp(6, new java.sql.Timestamp(banquet.geteDate().getTime()));
			ps.setInt(7,banquet.getId());
			ps.executeUpdate();
		}
		finally {
			close(null,ps,con);
		}
		
		
	}

}
