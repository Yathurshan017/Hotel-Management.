package com.data;

public class FinanceIncomeDAOImpl {

}
