package com.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.data.InventoryDAOImpl;

import com.model.Inventory;



/**
 * Servlet implementation class InventoryController
 */
@WebServlet("/InventoryController")
public class InventoryController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	InventoryDAOImpl inventoryUtil;
	String resource = "login.jsp";
	String message = null;
	
	@Override
	public void init() throws ServletException {

		super.init();
		inventoryUtil = new InventoryDAOImpl();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();

		try {
				
			String COMMAND = request.getParameter("COMMAND");
			
			if(COMMAND == null) {
				COMMAND = "LIST";
			}
			
			switch(COMMAND) {
				
			case "LIST":
				if(session.isNew()) {
					sessionChecker(request, response);
				}
				else {
					listInventory(request, response);
				}
				break;
				
				
				
			case "ADD":
				if(session.isNew()) {
					sessionChecker(request, response);
				}
				else {
					addInventory(request, response);
				}
				break;
				
			case "DELETE":
				if(session.isNew()) {
					sessionChecker(request, response);
				}
				else {
					deleteInventory(request,response);
				}
				break;
			
			case "SEARCH":
				if(session.isNew()) {
					sessionChecker(request, response);
				}
				else {
					SearchInventory(request,response);
				}
				break;
				
			case "LOAD":
				if(session.isNew()) {
					sessionChecker(request, response);
				}
				else {
					loadInventory(request,response);
				}
				break;
				
			case "UPDATE": 
				if(session.isNew()) {
					sessionChecker(request, response);
				}
				else {
					updateInventory(request,response);
				}
				break;
				
			case "CHECK": 
				if(session.isNew()) {
					sessionChecker(request, response);
				}
				else {
					checkInventory(request,response);
				}
				break;
				
			default:
				listInventory(request, response);
			}
		
		} catch (Exception e) {
			throw new ServletException(e);
		}
		
	}
	
	private void checkInventory(HttpServletRequest request, HttpServletResponse response) throws Exception {

		RequestDispatcher rd=request.getRequestDispatcher("add-new-inventory.jsp");
		rd.forward(request, response);	
		
	}


	private void sessionChecker(HttpServletRequest request, HttpServletResponse response) throws Exception {

		message = "Session Expired : TRY AGAIN";
		RequestDispatcher rd = request.getRequestDispatcher(resource);
		request.setAttribute("msg", message);
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	private void loadInventory(HttpServletRequest request, HttpServletResponse response) throws Exception{
		int id=Integer.parseInt(request.getParameter("id"));
		Inventory inventory=inventoryUtil.getInventory(id);
		request.setAttribute("INVENTORY",inventory);
		RequestDispatcher rd=request.getRequestDispatcher("update-inventory.jsp");
		rd.forward(request, response);
		
		
	}

	private void updateInventory(HttpServletRequest request, HttpServletResponse response) throws Exception{
		int id=Integer.parseInt(request.getParameter("id"));
		String inventoryName=request.getParameter("inventoryName");
		String supplierName=request.getParameter("supplierName");
		String supplierId=request.getParameter("supplierId");
		int qty=Integer.parseInt(request.getParameter("qty"));	
		String date=request.getParameter("date");
		
		
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		Date dom=new Date();
		dom=sdf.parse(date);
		
		
		
		Inventory inventory=new Inventory(id,inventoryName, supplierName, supplierId, dom, qty);
		inventoryUtil.updateInventory(inventory);
		
		listInventory(request,response);
	}


	private void SearchInventory(HttpServletRequest request, HttpServletResponse response) throws Exception{
		String fullName=request.getParameter("theSearchName");
		List<Inventory> inventoryList = inventoryUtil.searchInventorys(fullName);
		request.setAttribute("INVENTORY_LIST", inventoryList);
		
		RequestDispatcher rd = request.getRequestDispatcher("view-inventory.jsp");
		
		rd.forward(request, response);
		listInventory(request,response);
		
	}



	private void deleteInventory(HttpServletRequest request, HttpServletResponse response) throws Exception{
		int id=Integer.parseInt(request.getParameter("id"));
		inventoryUtil.deleteInventory(id);
		listInventory(request,response);
		
	}


	private void addInventory(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		String inventoryName = request.getParameter("inventoryName");
		String supplierName = request.getParameter("supplierName");
		String supplierId = request.getParameter("supplierId");
		
		String date = request.getParameter("date");
		int qty = Integer.valueOf(request.getParameter("qty"));
		
		
		
//		System.out.println(location + "   " + itemCategory + "   " + itemSubCategory);
SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		
		Date Idate = new Date();
		
		
		try {
			
			Idate = sdf.parse(date);
		} catch (ParseException e) {

			e.printStackTrace();
		}
		
		Inventory inventory = new Inventory(inventoryName, supplierName, supplierId, Idate, qty);
		
		inventoryUtil.addInventory(inventory);
		
		response.sendRedirect("InventoryController");
	}


	private void listInventory(HttpServletRequest request, HttpServletResponse response) throws Exception {

		List<Inventory> inventoryList = inventoryUtil.getInventorys();
		request.setAttribute("INVENTORY_LIST", inventoryList);
		
		RequestDispatcher rd = request.getRequestDispatcher("view-inventory.jsp");
		
		rd.forward(request, response);
		
	}

}
