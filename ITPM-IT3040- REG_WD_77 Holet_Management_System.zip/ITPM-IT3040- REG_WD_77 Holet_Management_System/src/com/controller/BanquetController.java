package com.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.data.BanquetDAOImpl;
import com.model.Banquet;


/**
 * Servlet implementation class BanquetController
 */
@WebServlet("/BanquetController")
public class BanquetController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
BanquetDAOImpl banquetUtil;
	
	String resource = "login.jsp";
	String message = null;
	
	@Override
	public void init() throws ServletException {

		super.init();
		banquetUtil = new BanquetDAOImpl();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();

		try {
				
			String COMMAND = request.getParameter("COMMAND");
			
			if(COMMAND == null) {
				COMMAND = "LIST";
			}
			
			switch(COMMAND) {
				
			case "LIST":
				if(session.isNew()) {
					sessionChecker(request, response);
				}
				else {
					listBanquet(request, response);
				}
				break;
				
				
				
			case "ADD":
				if(session.isNew()) {
					sessionChecker(request, response);
				}
				else {
					addBanquet(request, response);
				}
				break;
				
			case "DELETE":
				if(session.isNew()) {
					sessionChecker(request, response);
				}
				else {
					deleteBanquet(request,response);
				}
				break;
			
			case "SEARCH":
				if(session.isNew()) {
					sessionChecker(request, response);
				}
				else {
					SearchBanquet(request,response);
				}
				break;
				
			case "LOAD":
				if(session.isNew()) {
					sessionChecker(request, response);
				}
				else {
					loadBanquet(request,response);
				}
				break;
				
			case "UPDATE": 
				if(session.isNew()) {
					sessionChecker(request, response);
				}
				else {
					updateBanquet(request,response);
				}
				break;
				
			case "CHECK": 
				if(session.isNew()) {
					sessionChecker(request, response);
				}
				else {
					checkBanquet(request,response);
				}
				break;
				
			default:
				listBanquet(request, response);
			}
		
		} catch (Exception e) {
			throw new ServletException(e);
		}
		
	}
	
	private void checkBanquet(HttpServletRequest request, HttpServletResponse response) throws Exception {

		RequestDispatcher rd=request.getRequestDispatcher("banquet-hall-booking.jsp");
		rd.forward(request, response);
		
	}


	private void sessionChecker(HttpServletRequest request, HttpServletResponse response) throws Exception {

		message = "Session Expired : TRY AGAIN";
		RequestDispatcher rd = request.getRequestDispatcher(resource);
		request.setAttribute("msg", message);
		rd.forward(request, response);
	}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	private void loadBanquet(HttpServletRequest request, HttpServletResponse response) throws Exception{
		int id=Integer.parseInt(request.getParameter("id"));
		Banquet banquet=banquetUtil.getBanquet(id);
		request.setAttribute("BANQUET",banquet);
		RequestDispatcher rd=request.getRequestDispatcher("admin-update-banquet-booking.jsp");
		rd.forward(request, response);
		
		
	}

	private void updateBanquet(HttpServletRequest request, HttpServletResponse response) throws Exception{
		int id=Integer.parseInt(request.getParameter("id"));
		String gestName=request.getParameter("gestName");
		String mobile=request.getParameter("mobile");
		String eventType=request.getParameter("eventType");	
		String service=request.getParameter("service");
		String decoration=request.getParameter("decoration");
		String eDate=request.getParameter("eDate");
		
		
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		Date doc=new Date();
		doc=sdf.parse(eDate);
		
		
		
		Banquet banquet=new Banquet(id,gestName, mobile, eventType, service,decoration ,doc );
		banquetUtil.updateBanquet(banquet);
		
		listBanquet(request,response);
	}


	private void SearchBanquet(HttpServletRequest request, HttpServletResponse response) throws Exception{
		String gestName=request.getParameter("theSearchName");
		List<Banquet> banquetList = banquetUtil.searchBanquets(gestName);
		request.setAttribute("BANQUET_LIST", banquetList);
		
		RequestDispatcher rd = request.getRequestDispatcher("user-view-booked-banquet.jsp");
		
		rd.forward(request, response);
		listBanquet(request,response);
		
	}



	private void deleteBanquet(HttpServletRequest request, HttpServletResponse response) throws Exception{
		int id=Integer.parseInt(request.getParameter("id"));
		banquetUtil.deleteBanquet(id);
		listBanquet(request,response);
		
	}


	private void addBanquet(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		String gestName=request.getParameter("gestName");
		String mobile=request.getParameter("mobile");
		String eventType=request.getParameter("eventType");	
		String service=request.getParameter("service");
		String decoration=request.getParameter("decoration");
		String eDate=request.getParameter("eDate");
		
		
		
//		System.out.println(location + "   " + itemCategory + "   " + itemSubCategory);
SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		
		Date dateOfCheck = new Date();
		
		
		try {
			
			dateOfCheck = sdf.parse(eDate);
		} catch (ParseException e) {

			e.printStackTrace();
		}
		
		Banquet banquet = new Banquet(gestName, mobile, eventType, service, decoration, dateOfCheck);
		
		banquetUtil.addBanquet(banquet);
		
		response.sendRedirect("BanquetController");
	}


	private void listBanquet(HttpServletRequest request, HttpServletResponse response) throws Exception {

		List<Banquet> banquetList = banquetUtil.getBanquets();
		request.setAttribute("BANQUET_LIST", banquetList);
		
		RequestDispatcher rd = request.getRequestDispatcher("user-view-booked-banquet.jsp");
		
		rd.forward(request, response);
		
	}

}
