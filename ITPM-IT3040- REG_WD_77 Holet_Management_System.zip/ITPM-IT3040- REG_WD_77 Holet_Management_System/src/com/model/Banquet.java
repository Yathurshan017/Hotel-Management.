package com.model;

import java.util.Date;

public class Banquet {
	
	private int id;
	private String gestName;
	private String mobile;
	private String eventType;
	private String service;
	private String decoration;
	private Date eDate;
	
	
	public Banquet(String gestName,String mobile,String eventType, String service, String decoration ,Date eDate) {
		super();
		this.gestName = gestName;
		this.mobile = mobile;
		this.eventType = eventType;
		this.service = service;
		this.decoration = decoration;
		this.eDate = eDate;
	}
	public Banquet(int id, String gestName, String mobile,String eventType, String service, String decoration,Date eDate) {
		super();
		this.id = id;
		this.gestName = gestName;
		this.mobile = mobile;
		this.eventType = eventType;
		this.service = service;
		this.decoration = decoration;
		this.eDate = eDate;
		
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getGestName() {
		return gestName;
	}
	public void setGestName(String gestName) {
		this.gestName = gestName;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getEventType() {
		return eventType;
	}
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	public String getService() {
		return service;
	}
	public void setService(String service) {
		this.service = service;
	}
	public String getDecoration() {
		return decoration;
	}
	public void setDecoration(String decoration) {
		this.decoration = decoration;
	}
	public Date geteDate() {
		return eDate;
	}
	public void seteDate(Date eDate) {
		this.eDate = eDate;
	}
	@Override
	public String toString() {
		return "Banquet [id=" + id + ", gestName=" + gestName + ", mobile=" + mobile + ", eventType=" + eventType
				+ ", service=" + service + ", decoration=" + decoration + ", eDate=" + eDate + "]";
	}
	
	

}
