package com.model;

import java.util.Date;

public class Inventory {
	
	private int id;
	private String inventoryName;
	private String supplierName;
	private String  supplierId;
	private  Date date;
	private int qty;
	

	
	public Inventory(String inventoryName,String supplierName,String  supplierId, Date date,int qty) {
		super();
		this.inventoryName = inventoryName;
		this.supplierName = supplierName;
		this.supplierId = supplierId;
		this.date = date;
		this.qty = qty;
		
	}
	public Inventory(int id, String inventoryName,String supplierName,String  supplierId, Date date,int qty) {
		super();
		this.id = id;
		this.inventoryName = inventoryName;
		this.supplierName = supplierName;
		this.supplierId = supplierId;
		this.date = date;
		this.qty = qty;
		
		
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getInventoryName() {
		return inventoryName;
	}
	public void setInventoryName(String inventoryName) {
		this.inventoryName = inventoryName;
	}
	public String getSupplierName() {
		return supplierName;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	public String getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	@Override
	public String toString() {
		return "Inventory [id=" + id + ", inventoryName=" + inventoryName + ", supplierName=" + supplierName
				+ ", supplierId=" + supplierId + ", date=" + date + ", qty=" + qty + "]";
	}
	
	
	
	
	

}
